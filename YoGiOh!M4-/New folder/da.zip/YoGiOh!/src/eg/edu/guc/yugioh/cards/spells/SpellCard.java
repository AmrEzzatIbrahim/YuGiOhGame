package eg.edu.guc.yugioh.cards.spells;

import java.io.IOException;

import eg.edu.guc.yugioh.cards.Card;
import eg.edu.guc.yugioh.cards.MonsterCard;

public class SpellCard extends Card {

	public SpellCard(String name, String description) {
		super(name, description);

	}
	public SpellCard copy() {
		return new SpellCard(this.getName(),this.getDescription());
	}
	public static void increase(MonsterCard monster, int increase) {
		monster.setAttackPoints(monster.getAttackPoints() + increase);
		monster.setDefensePoints(monster.getDefensePoints() + increase);
	}
}

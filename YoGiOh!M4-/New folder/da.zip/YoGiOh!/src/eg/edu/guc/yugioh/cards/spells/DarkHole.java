package eg.edu.guc.yugioh.cards.spells;

import java.io.IOException;

import eg.edu.guc.yugioh.cards.MonsterCard;

public class DarkHole extends Raigeki {

	public DarkHole(String name, String description) {
		super(name, description);
	}

	public void action(MonsterCard monster) {
		if (monster != null) {
			super.action(monster);
			getBoard()
					.getActivePlayer()
					.getField()
					.removeMonsterToGraveyard(
							getBoard().getActivePlayer().getField()
									.getMonstersArea());
		}
	}
}

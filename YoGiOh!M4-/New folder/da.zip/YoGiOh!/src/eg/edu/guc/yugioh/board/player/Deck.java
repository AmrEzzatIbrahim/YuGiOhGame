package eg.edu.guc.yugioh.board.player;

import eg.edu.guc.yugioh.cards.Card;
import eg.edu.guc.yugioh.cards.Location;
import eg.edu.guc.yugioh.cards.MonsterCard;
import eg.edu.guc.yugioh.cards.spells.SpellCard;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class Deck {

	private static ArrayList<Card> monsters;
	private static ArrayList<Card> spells;
	private ArrayList<Card> deck;
	private static boolean loadedDeck=false;


	public Deck() throws IOException{
		deck= new ArrayList<Card>() ;
		if (!loadedDeck){
			monsters=loadCardsFromFile("Database-Monsters.csv");
			spells=loadCardsFromFile("Database-Spells.csv");
			loadedDeck=true;
		}

		buildDeck(monsters, spells);
	}


	public ArrayList<Card> getDeck() {
		return deck;
	}

  

	public ArrayList<Card> loadCardsFromFile(String path) throws IOException{

		String currentLine = "";
		FileReader fileReader = new FileReader(path);
		BufferedReader br = new BufferedReader(fileReader);
        ArrayList<Card> a=new ArrayList<Card>() ;
          if(path.compareTo("Database-Monsters.csv")==0){
      		while ((currentLine = br.readLine()) != null) {
    			String [] result= currentLine.split(",");
        	  MonsterCard x = new MonsterCard(result[1],result[2],Integer.parseInt(result[5]),Integer.parseInt(result[3]),Integer.parseInt(result[4]));
			a.add(x.copy());
      		}
      		
          }
          if(path.compareTo("Database-Spells.csv")==0){
      		while ((currentLine = br.readLine()) != null) {
    			String [] result= currentLine.split(",");
        	  SpellCard x = new SpellCard(result[1],result[2]);
			a.add(x.copy());
        
      		}
          }
          return a;
	}

	private void buildDeck(ArrayList<Card> monsters, ArrayList<Card> spells){
		for(int i=0;i<15;i++){
    	 int x=(int) Math.floor(Math.random()*30);
    	 MonsterCard m=(MonsterCard)monsters.get(x);
    	 deck.add(m);
     }
		for(int i=0;i<5;i++){
	    	 int x=(int) Math.floor(Math.random()*10);
	    	 
	    	 deck.add(spells.get(x));
	     }
		shuffleDeck();
	}

	private void shuffleDeck (){
    ArrayList<Card> temp=new ArrayList<Card>();
    while(!deck.isEmpty()){
		int x=(int) Math.floor(Math.random()*deck.size());
    	temp.add(deck.remove(x));
    }
	deck=temp;
	}

	public ArrayList<Card> drawNCards(int n){
		ArrayList<Card> nCards=new ArrayList<Card>();
		for(int i=0;i<n;i++){
			nCards.add(drawOneCard());
		}
		return nCards;
	}

	public Card drawOneCard(){
        Card x=deck.remove(deck.size()-1);
        		x.setLocation(Location.DECK);
		return x;
         
	}


}		




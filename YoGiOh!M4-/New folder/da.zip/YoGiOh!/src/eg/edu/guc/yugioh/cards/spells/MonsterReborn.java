package eg.edu.guc.yugioh.cards.spells;

import java.io.IOException;

import eg.edu.guc.yugioh.cards.Card;
import eg.edu.guc.yugioh.cards.MonsterCard;

public class MonsterReborn extends SpellCard {

	public MonsterReborn(String name, String description) throws IOException {
		super(name, description);
	}

	public void action(MonsterCard monster){
		MonsterCard max = new MonsterCard("","",0,0,0);
		boolean flag = false;
		for (int i = 0; i < getBoard().getActivePlayer().getField()
				.getGraveyard().size(); i++) {
			if (getBoard().getActivePlayer().getField().getGraveyard().get(i) instanceof MonsterCard) {
				if (((MonsterCard) (getBoard().getActivePlayer().getField()
						.getGraveyard().get(i))).getAttackPoints() > max
						.getAttackPoints()) {
					max = (MonsterCard) getBoard().getActivePlayer().getField()
							.getGraveyard().get(i);
					flag = false;
				}
			}
		}
		for (int i = 0; i < getBoard().getOpponentPlayer().getField()
				.getGraveyard().size(); i++) {
			if (getBoard().getOpponentPlayer().getField().getGraveyard().get(i) instanceof MonsterCard) {
				if (((MonsterCard) (getBoard().getOpponentPlayer().getField()
						.getGraveyard().get(i))).getAttackPoints() > max
						.getAttackPoints()) {
					max = (MonsterCard) getBoard().getActivePlayer().getField()
							.getGraveyard().get(i);
					flag = true;
				}
			}
		}
		getBoard().getActivePlayer().getField().getMonstersArea().add(max);
		if (!flag) {
			getBoard()
					.getActivePlayer()
					.getField()
					.getGraveyard()
					.remove(getBoard().getActivePlayer().getField()
							.getGraveyard().indexOf(max));
		} else {
			getBoard()
					.getOpponentPlayer()
					.getField()
					.getGraveyard()
					.remove(getBoard().getOpponentPlayer().getField()
							.getGraveyard().indexOf(max));
		}

	}

}

package eg.edu.guc.yugioh.cards;

import java.io.IOException;

public class MonsterCard extends Card {

	private int level;
	private int defensePoints;
	private int attackPoints;
	private Mode mode;

	public MonsterCard(String name, String description, int level,int attackPoints, int defensePoints) {
		super(name, description);
		this.level = level;
		this.defensePoints = defensePoints;
		this.attackPoints = attackPoints;
		this.mode = Mode.DEFENSE;

	}

	public Mode getMode() {
		return mode;
	}

	public void setMode(Mode mode) {
		this.mode = mode;
	}

	public int getLevel() {
		return level;
	}

	public void setDefensePoints(int defensePoints) {
		this.defensePoints = defensePoints;
	}

	public void setAttackPoints(int attackPoints) {
		this.attackPoints = attackPoints;
	}

	public int getDefensePoints() {
		return defensePoints;
	}

	public int getAttackPoints() {
		return attackPoints;
	}
	public MonsterCard copy() {
		return new MonsterCard(this.getName(),this.getDescription(),level,attackPoints,defensePoints);
	}

}
